var toronto = new Array();
var back = false;

$(document).ready(function() {
	$("#date1").hide();
	$("#date2").hide();
	$("#date3").hide();
	$("#datesGroup").hide();
	$("#forecastContent").hide();
	
	$.ajax({
		type: "GET",
		url: "a3_torontoWeather.json",
		dataType: "json",
		success: parsejson
	});
	
	$.ajax({
		type: "GET",
		url: "assignment3.json",
		dataType: "json",
		success: parsejson2
	});

	function parsejson(data) {
		var start = data.query.results;
		var forecast = start.item.forecast;
		
		$("#lastBuildDate").html(start.lastBuildDate);
		$("#location").html("<b>Location:</b> " + start.location.city + ", " + start.location.region + " ," + start.location.country);
		
		$("#wind").click(function() {
			$("#panel").html("<h2>Wind</h2>" +
							 "<b>Chill:</b> " + start.wind.chill +
							 "<br><b>Direction:</b> " + start.wind.direction +
							 "<br><b>Speed</b>: " + start.wind.speed);
		});
		
		$("#atmosphere").click(function() {
			$("#panel").html("<h2>Atmosphere</h2>" +
							 "<b>Humidity:</b> " + start.atmosphere.humidity +
							 "<br><b>Pressure:</b> " + start.atmosphere.pressure +
							 "<br><b>Rising</b>: " + start.atmosphere.rising +
							 "<br><b>Visibility</b>: " + start.atmosphere.visibility);
		});

		
		$("#astronomy").click(function() {
			$("#panel").html("<h2>Astronomy</h2>" +
							 "<b>Sunrise:</b> " + start.astronomy.sunrise +
							 "<br><b>Sunset:</b> " + start.astronomy.sunset);
		});
		
		$("#showMap").click(function() {
			$("#showMap").hide();
			mapToronto = new google.maps.LatLng(start.item.lat, start.item.long);
			
			var mapOptions = {
				center: mapToronto,
				zoom: 10,
				mapTypeId: google.maps.MapTypeId.ROADMAP
			};
			
			map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions);
			
			var myLoc = new google.maps.Marker({
				map: map,
				animation: google.maps.Animation.DROP,
				position: mapToronto
			});

			var info = new google.maps.InfoWindow({
				content: "Title: " + start.item.title 
			});
		});
		
		$("#forecast").click(function() {
			$("#wind").toggle();
			$("#atmosphere").toggle();
			$("#astronomy").toggle();
			$("#date1").toggle();
			$("#date2").toggle();
			$("#date3").toggle();
			$("#date1Label").html(forecast[0].date);
			$("#date2Label").html(forecast[1].date);
			$("#date3Label").html(forecast[2].date);
			$("#date4Label").html(forecast[3].date);
			$("#datesGroup").toggle();
			$("#forecastContent").toggle();
			toggleButtonText();
		});
		
		function toggleButtonText() {
			if (back == false) {
				back = true;
				$("#forecast").html("&#x2190 Back");
			} else {
				back = false;
				$("#forecast").html("Forecast");
			}
		}
		
		$("#date1").click(function() {
			showForecast(0);
		});
		$("#date2").click(function() {
			showForecast(1);
		});
		$("#date3").click(function() {
			showForecast(2);
		});
		$("#date4").click(function() {
			showForecast(3);
		});
		
		function showForecast(num) {
			$("#forecastContent").html("<b>Day:</b> " + forecast[num].day +
									   "<br><b>High:</b> " + forecast[num].high + "&#8451" +
									   "<br><b>Low:</b> " + forecast[num].low + "&#8451" +
									   "<br><i>\"" + forecast[num].text + "\"</i>");
		}
	}
	
	function parsejson2(data) {
		var start2 = data.student;

		$("#about").click(function() {
			$("#myModal").css("display", "block");
			$("#aboutText").html("<b>Name:</b>               " + data.name +
								 "<br><b>Student Number:</b> " + data.number +
								 "<br><b>Program:</b>        " + data.program +
								 "<br><b>Quote:</b>          " + data.quote +
								 "<br><img src=" + data.image + ">");
		});
	
		$(".close").click(function() {
			$("#myModal").css("display", "none");
		});
	}
});	// End of doc ready

